(function() {
    "use strict";
    var app = angular.module('app', ['onsen']);
})();
